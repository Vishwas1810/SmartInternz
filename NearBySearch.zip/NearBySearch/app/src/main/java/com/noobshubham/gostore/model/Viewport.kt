package com.noobshubham.gostore.model

data class Viewport(
    var northeast: Northeast? = null,
    var southwest: Southwest? = null
)
