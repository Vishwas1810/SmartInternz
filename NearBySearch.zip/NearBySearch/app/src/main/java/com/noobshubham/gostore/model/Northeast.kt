package com.noobshubham.gostore.model

data class Northeast(
    var lat: Double = 0.0,
    var lng: Double = 0.0
)