package com.noobshubham.gostore.model

data class UserData(
    val username: String,
    val email: String,
    val password: String
)